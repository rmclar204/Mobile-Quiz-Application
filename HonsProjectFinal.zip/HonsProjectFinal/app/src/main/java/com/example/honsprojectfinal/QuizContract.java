package com.example.honsprojectfinal;

/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This is used to store the questions and categories in an SQLite database.
 *
 */
import android.provider.BaseColumns;

public final class QuizContract {

    private QuizContract() {
    }

    public static class CategoriesTable implements BaseColumns {
        public static final String TABLE_NAME = "quiz_categories";
        public static final String COLUMN_NAME = "name";
    }

    public static class QuestionsTable implements BaseColumns {


        public static final String TABLE_NAME = "quiz_questions";
        public static final String COLUMN_QUESTION = "question";
        public static final String COLUMN_OPTION1 = "option1";
        public static final String COLUMN_OPTION2 = "option2";
        public static final String COLUMN_OPTION3 = "option3";
        public static final String COLUMN_OPTION4 = "option4";
        public static final String COLUMN_ANS_NUMBER = "answer_Number";
        public static final String COLUMN_CAT_ID = "category_id";
        public static final String COLUMN_IMAGE_ID = "image_id";
    }
}


