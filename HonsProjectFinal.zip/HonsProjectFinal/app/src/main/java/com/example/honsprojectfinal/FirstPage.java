package com.example.honsprojectfinal;

/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This is the simple home page providing the user with
 * easy access to the required sections of the app.
 *
 */
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;


public class FirstPage extends AppCompatActivity {
    private Button btnLogin, btnRegister;
    private Button btnHelp;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    //This was set to enable orientation changes
    Resources resources;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        resources = btnRegister.getResources();
    // Take user to help page
        btnHelp = findViewById(R.id.btnHelp1);
        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FirstPage.this, HelpPage.class);
                startActivity(intent);
            }
        });
    // Take user to login page
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FirstPage.this, Login.class);
                startActivity(intent);
            }
        });
    // Take user to register page
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FirstPage.this, Register.class);
                startActivity(intent);
            }
        });
    }
}
