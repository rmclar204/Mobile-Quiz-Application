package com.example.honsprojectfinal;


/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This page is used for getting and setting each category for the quiz
 * Each category will have a category ID and a category name.
 *
 */

import androidx.annotation.NonNull;

public class CategorySetter {
    /// Set ID's
    public static  final int GENERAL_KNOWLEDGE = 1;
    public static final int MATHEMATICS = 2;
    public static final int LOGIC = 3;
    private int id;
    private String name;
    public CategorySetter(){

    }
// Set Category name
    public CategorySetter(String name) {
        this.name = name;
    }
// Get category ID
    public int getId() {
        return id;
    }
// Set Category ID
    public void setId(int id) {
        this.id = id;
    }
// Get Category Name
    public String getName() {
        return name;
    }
// Set Category Name
    public void setName(String name) {
        this.name = name;
    }
// Send category info to string
    @NonNull
    @Override
    public String toString() {
        return getName();
    }
}
