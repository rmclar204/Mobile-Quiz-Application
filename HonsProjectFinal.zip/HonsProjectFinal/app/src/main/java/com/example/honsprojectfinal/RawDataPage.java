package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This page is used to display the users raw data if they were unreachable due to any unforeseen circumstances,
 * the user would screenshot this and send the output to the developer for analysis.
 *
 *
 */
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static com.example.honsprojectfinal.FinalPage.array;
import static com.example.honsprojectfinal.FinalPage.dataFileName;

public class RawDataPage extends AppCompatActivity {
    private TextView txtAttempt, txtWrong, txtTime, txtMoreCat;
    private Button btnFinalBack, btnPage;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_data);
        btnFinalBack = findViewById(R.id.btnFinalBack);
        btnPage = findViewById(R.id.btnPage);
        //Take user back to final page
        btnFinalBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(RawDataPage.this, FinalPage.class);
                startActivity(intent);
            }
        });
        // Take user to start quiz page.
        btnPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(RawDataPage.this, MainActivity.class);
                startActivity(intent);
            }
        });
        BufferedReader br = null;

        String[] partial;

        txtAttempt = findViewById(R.id.txtAttempt);
        txtAttempt.append("\n");
        txtWrong = findViewById(R.id.txtWrong);
        txtWrong.append("\n");
        txtTime = findViewById(R.id.txtTime);
        txtTime.append("\n");
        txtMoreCat = findViewById(R.id.txtMoreCat);
        txtMoreCat.append("\n");

        String sCurrentLine = null;

        try {
            br = new BufferedReader(new FileReader(dataFileName));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while (true) {
            try {
                if (!((sCurrentLine = br.readLine()) != null)) break;
            } catch (IOException e) {
                e.printStackTrace();
            }
            array = sCurrentLine.split(",");

            partial = new String[array.length >> 0];
            //This gets all the attempt numbers from the file
            for (int i = 1; i < array.length; i += 3) {
                partial[(i)] = array[i];
                txtAttempt.append(array[i]);
                txtAttempt.append("\n");

            }
            //This gets all the wrong attempts from the file
            for (int i = 2; i < array.length; i += 2) {
                partial[(i-1) >> 0] = array[i];
                txtWrong.append(array[i]);
                txtWrong.append("\n");

            }
            //This gets the category for each attempt
            for (int i = 0; i < array.length; i += 4) {
                partial[(i)] = array[i];
                txtMoreCat.append(array[i]);
                txtMoreCat.append("\n");

            }
            //This gets the time taken for each attempt
            for (int i =3; i < array.length; i+=3){
                partial[(i)] = array[i];
                txtTime.append(array[i]);
                txtTime.append("\n");
            }


        }
    }
}
