package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This class is used to handle the registration functionality of the programme.
 *
 */
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.example.honsprojectfinal.Login.userName;

public class Register extends AppCompatActivity {
    UserDetailsDb db;
    EditText uName, pWord, pWordConfirm;
    Button bRegister, bLogin;
    public static Double timesAccessed;
    public static String dataFileName = "/data/user/0/com.example.honsprojectfinal/" + userName + "scoreData" + ".csv";
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db = new UserDetailsDb(this);

            uName =  findViewById(R.id.txtUserName);
            pWord =  findViewById(R.id.txtPassword);
            pWordConfirm =  findViewById(R.id.txtConfirmPassword);
            bRegister =  findViewById(R.id.btnRegister);
            bLogin =  findViewById(R.id.btnLogin);
            //This verifies the users inputs for both passwords and user name.
            bRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String userName = uName.getText().toString();
                    String passWord = pWord.getText().toString();
                    String passWordConfirm = pWordConfirm.getText().toString();
                    db.getReadableDatabase();
                    db.insert(" ", " ", 0.0);
                    Boolean chkUserName = db.checkUserName(userName);
                    //Checks if the user name already exists.
                    if (chkUserName == true) {
                        Toast.makeText(getApplicationContext(), "User name is already taken please make a new one", Toast.LENGTH_LONG).show();
                    }else {
                        //Checks if any boxes are empty.
                        if (userName.equals("") || passWord.equals("") || passWordConfirm.equals("")) {
                            Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_LONG).show();
                        }else {
                            //Verifies password
                            if (passWord.length() < 8 && !isValidPassword(passWord)) {
                                Toast.makeText(getApplicationContext(), "Password must contain more than 5 letters and must contain 1 number, 1 symbol and 1 capital", Toast.LENGTH_LONG).show();
                            }else {
                                //Checks if both passwords match each other.
                                if (passWord.equals(passWordConfirm)) {
                                    timesAccessed = 0.0;
                                    Boolean insert = db.insert(userName, passWord, timesAccessed);
                                    if (insert == true) {
                                        Toast.makeText(getApplicationContext(), "Registration successful, please click login. ", Toast.LENGTH_LONG).show();
                                        try {
                                            FileWriter fw = new FileWriter(dataFileName, true);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }

                                    }
                                }else {
                                    Toast.makeText(getApplicationContext(), "passwords do not match", Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    }
                }
            });

        //Takes user to login page.
        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent i = new Intent(Register.this, Login.class);
                startActivity(i);
            }
        });

    }
    //This checks to see if the password matches the criteria.
    public static boolean isValidPassword(final String password)
    {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-5])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);
        return matcher.matches();
    }

}