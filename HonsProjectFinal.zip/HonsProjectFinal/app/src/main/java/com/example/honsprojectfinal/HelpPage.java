package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This class is used for displaying the help information to the users.
 *
 */
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;

public class HelpPage extends AppCompatActivity {
    private Button loginBtn;
    private Button backBtn;
    Resources resources;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_page);
        backBtn = findViewById(R.id.testButton);
        loginBtn = findViewById(R.id.loginBtn);
        resources = loginBtn.getResources();
        //Take user back to homepage.
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(HelpPage.this, FirstPage.class);
                startActivity(intent);
            }
        });
        //Takes user to login page
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(HelpPage.this, Register.class);
                startActivity(intent);
            }
        });
    }
}
