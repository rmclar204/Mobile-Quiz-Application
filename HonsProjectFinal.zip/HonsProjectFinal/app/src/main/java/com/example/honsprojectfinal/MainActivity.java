package com.example.honsprojectfinal;

/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This class handles the functionality for before starting the quiz functions.
 *
 */


import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;
import static com.example.honsprojectfinal.QuizActivity.score;
import static com.example.honsprojectfinal.Login.userName;


public class MainActivity extends AppCompatActivity {
    public static long startTime;
    private static final int QUIZ_CODE = 1;
    public static final String CAT_ID = "CatID";
    public static final String CAT_NAME = "CatNAME";
    public static String categoryName;
    public static int categoryID;
    public static int timesCompleted;
    private Spinner spinnerCategory;
    private TextView txtWelcome;
    private Button btnLogOut;
    public static UserDetailsDb db;
    public static double s;
    public static boolean runOnce;
    public static String uName;
    Resources resources;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new UserDetailsDb(this);
        db.getReadableDatabase();
        SharedPreferences prefs;
        btnLogOut = findViewById(R.id.btnLogout);
        txtWelcome = findViewById(R.id.txtWelcome);
        resources = txtWelcome.getResources();
        db = new UserDetailsDb(this);
        spinnerCategory = findViewById(R.id.spinner_Categories);
        spinnerCategory.getBackground().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
        db.getWritableDatabase();
        timesCompleted++;
        txtWelcome.append(" Welcome " + userName );
        uName = userName;
        loadCategories();
        Button btnStart = findViewById(R.id.btnStart);

        // Logs user out of application.
        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                PackageManager packageManager = MainActivity.this.getPackageManager();
                Intent intent = packageManager.getLaunchIntentForPackage(MainActivity.this.getPackageName());
                ComponentName componentName = intent.getComponent();
                Intent mainIntent = Intent.makeRestartActivityTask(componentName);
                MainActivity.this.startActivity(mainIntent);
                Runtime.getRuntime().exit(0);

            }
        });
        //Start Quiz
        final UserDetailsDb finalDb = db;
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                score = 0;
                startTime = System.currentTimeMillis();
                runOnce = false;
                s = db.getTimesAccessed(userName);
                s = s + 1.0;
                db.update(userName, s);
                startQuiz();
            }
        });
    }
    //Get categories from database.
    private void loadCategories() {
        QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);
        List<CategorySetter> categories = dbHelper.getAllCategories();
        ArrayAdapter<CategorySetter> adapterCategories = new ArrayAdapter<>(this, R.layout.colored_spinner_layout , categories);
        adapterCategories.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapterCategories);
    }
    //Begin quiz, get selected category.
    private void startQuiz() {
        CategorySetter selectedCategorySetter = (CategorySetter) spinnerCategory.getSelectedItem();
        categoryID = selectedCategorySetter.getId();
        categoryName = selectedCategorySetter.getName();
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        intent.putExtra(CAT_ID, categoryID);
        intent.putExtra(CAT_NAME, categoryName);
        startActivityForResult(intent, QUIZ_CODE);
        timesCompleted++;
    }

}



