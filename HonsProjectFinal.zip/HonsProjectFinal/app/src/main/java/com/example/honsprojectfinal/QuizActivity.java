package com.example.honsprojectfinal;

/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This page handles the quiz functionality.
 *
 */


import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;


public class QuizActivity extends AppCompatActivity {
    private static final long TIMETOTAL = 30000;
    private static final String Q_SCORE = "Score";
    private TextView textViewQuestion;
    private TextView textViewScore;
    private TextView textViewQuestionCount;
    private TextView textViewCategory;
    private TextView textViewCountDown;
    private RadioGroup rbGroup;
    private RadioButton rOption1;
    private RadioButton rOption2;
    private RadioButton rOption3;
    private RadioButton rOption4;
    private ImageView imgQuestion;
    public Button buttonConfirmNext;
    private ColorStateList textColorDefaultRb;
    private ColorStateList textColorDEfaultCd;
    private CountDownTimer timer;
    public long timeLeftMs;
    private ArrayList<Question> questions;
    private int questionCounter;
    private int numberQuestions;
    private Question currentQuestion;
    public static double score;
    private boolean answered;
    private long backPressedTime;
    private int numAttemtps;
    private int questionNum;
    public static int numWrong;
    private String ans;
    private ImageView imageQuestion;
    public String timeFormatted;
    private UserDetailsDb db;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        numAttemtps = 0;
        score = 0;
        questionNum = 0;
        numWrong =0;
        textViewQuestion = findViewById(R.id.txtViewQuestion);
        textViewScore = findViewById(R.id.txtViewScore);
        textViewQuestionCount = findViewById(R.id.txtQuestionCount);
        textViewCategory = findViewById(R.id.txtCategory);
        textViewCountDown = findViewById(R.id.txtViewCountdown);
        imageQuestion = findViewById(R.id.imageViewQuestion);
        rbGroup = findViewById(R.id.radio_group);
        imgQuestion = findViewById(R.id.imageViewQuestion);
        db = new UserDetailsDb(this);
        rOption1 = findViewById(R.id.radioBtn1);
        rOption2 = findViewById(R.id.radioBtn2);
        rOption3 = findViewById(R.id.radioBtn3);
        rOption4 = findViewById(R.id.radioBtn4);
        buttonConfirmNext = findViewById(R.id.btnConfirm);
        textColorDefaultRb = rOption1.getHintTextColors();
        textColorDEfaultCd = textViewCountDown.getTextColors();
        textViewScore.getResources();
        Intent intent = getIntent();
        int categoryID = intent.getIntExtra(MainActivity.CAT_ID, 0);
        String categoryName = intent.getStringExtra(MainActivity.CAT_NAME);
        textViewCategory.setText("Category: " + categoryName);
        if (categoryID ==0 || categoryID==1)
        {
            imageQuestion.setVisibility(View.INVISIBLE);
        }
        else {
            imageQuestion.setVisibility(View.VISIBLE);
        }

            QuizDbHelper database = QuizDbHelper.getInstance(this);
            //Get List of questions from database
            questions = database.getQuestions(categoryID);
            //Get total number of questions to ensure question limit is 10
            numberQuestions = questions.size();
            //Shuffle Questions to ensure user does not get questions in order.
            Collections.shuffle(questions);
            //Display next question.
            nextQuestion();
            if (!answered){
                beginTimer();
            }else{
                updateTimer();
                showCorrectAnswer();
            }

        /**This checks to see if any radio buttons havent been clicked, if one hasnt been clicked
         * the system will ask for an input, if an answer has been selected the system checks the answer
         * if the answer is correct the system changes the question.
         *
         */
        buttonConfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                if (!answered){
                    if (rOption1.isChecked() || rOption2.isChecked() || rOption3.isChecked() || rOption4.isChecked()){
                        checkAnswer();
                    }else{
                        Toast.makeText(QuizActivity.this, "please select an answer", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                        nextQuestion();
                }
            }
        });

    }

    /** This gets the next question until the question counter is greater than 10 then
     * the quiz finishes.*/
    private void nextQuestion(){
        numAttemtps = 0 ;
        questionNum++;
        rOption1.setTextColor(textColorDefaultRb);
        rOption2.setTextColor(textColorDefaultRb);
        rOption3.setTextColor(textColorDefaultRb);
        rOption4.setTextColor(textColorDefaultRb);
        rbGroup.clearCheck();
        if (questionCounter < 10){
            currentQuestion = questions.get(questionCounter);
            textViewQuestion.setText(currentQuestion.getQuestion());
            rOption1.setText(currentQuestion.getOption1());
            rOption1.setTextColor(getResources().getColor(R.color.white));
            rOption2.setText(currentQuestion.getOption2());
            rOption2.setTextColor(getResources().getColor(R.color.white));
            rOption3.setText(currentQuestion.getOption3());
            rOption3.setTextColor(getResources().getColor(R.color.white));
            rOption4.setText(currentQuestion.getOption4());
            rOption4.setTextColor(getResources().getColor(R.color.white));
            int imageId = currentQuestion.getImageID();
            imgQuestion.setImageDrawable(getResources().getDrawable(imageId));
            questionCounter++;
            textViewQuestionCount.setText("Question: " + questionCounter + "/" + 10);
            answered = false;
            buttonConfirmNext.setText(("confirm"));
            timeLeftMs = TIMETOTAL;
            beginTimer();
        }else{
            stopQuiz();
        }
    }
    /**This handles the countdown starting from 30 seconds and finishing**/
    private void beginTimer(){
        timer = new CountDownTimer(timeLeftMs, 1000) {
            @Override
            public void onTick(long timeTillFinish) {
                timeLeftMs = timeTillFinish;
                updateTimer();
            }

            @Override
            public void onFinish() {
                timeLeftMs = 0;
                updateTimer();
                checkAnswer();
            }
        }.start();
    }
    /**This changes the countdown timer colour to red if it gets below 5 seconds**/
    public void updateTimer(){
        int mins = (int) (timeLeftMs / 1000) / 60;
        int secs = (int) (timeLeftMs / 1000) % 60;
         timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", mins, secs);
        textViewCountDown.setText(timeFormatted);
        if (timeLeftMs < 5000) {
            textViewCountDown.setTextColor(Color.RED);
            if (timeLeftMs == 0)
            {
                numAttemtps = 4;
                numWrong = numWrong + 4;
                checkAnswer();
                showCorrectAnswer();
                Toast.makeText(getApplicationContext(), "Ran out of time", Toast.LENGTH_LONG).show();

            }
        }else       {
            textViewCountDown.setTextColor(textColorDEfaultCd);
        }
    }
    /**This checks the users answer to see if it is correct or not
     * If the answer is correct the system will add 1 to the score and move on.
     * If the answer is wrong the system will ask for a new one and add 1 to the wrong answers.
    **/
    private void checkAnswer(){
        timer.cancel();
        RadioButton rbSelected = findViewById(rbGroup.getCheckedRadioButtonId());
        int answerNo = rbGroup.indexOfChild(rbSelected) + 1;
        if (answerNo == currentQuestion.getAnsNumber()){
            score++;
            textViewScore.setText("Score: " + score);
            answered = true;
            showCorrectAnswer();
        }
        if (numAttemtps >= 4){
            answered = true;
            showCorrectAnswer();
        }
        else{
            Toast.makeText(getApplicationContext(), "try again", Toast.LENGTH_LONG).show();
            numAttemtps++;
            numWrong++;
        }
    }

    /**This checks for the correct answer then changes the colours of the radio buttons(Correct - Green), (Wrong - Red)
     *  and displays the correct answer.
     **/
     private void showCorrectAnswer(){
        rOption1.setTextColor(Color.RED);
         rOption2.setTextColor(Color.RED);
         rOption3.setTextColor(Color.RED);
         rOption4.setTextColor(Color.RED);
        switch (currentQuestion.getAnsNumber()){
            case 1:
                rOption1.setTextColor(Color.GREEN);
               ans = currentQuestion.getOption1();
                textViewQuestion.setText("Answer 1, " + ans + " is correct!");
                break;
            case 2:
                rOption2.setTextColor(Color.GREEN);
                ans = currentQuestion.getOption2();
                textViewQuestion.setText("Answer 2, " + ans + " is correct!");
                break;
            case 3:
                rOption3.setTextColor(Color.GREEN);
                ans = currentQuestion.getOption3();
                textViewQuestion.setText("Answer 3, " + ans + " is correct!");
                break;
            case 4:
                rOption4.setTextColor(Color.GREEN);
                ans = currentQuestion.getOption4();
                textViewQuestion.setText("Answer 4, " + ans + " is correct!");
                break;
        }
        if (questionCounter < numberQuestions){
            buttonConfirmNext.setText("Next Question");
        }else{
            buttonConfirmNext.setText("Finish");
        }
    }
    /**Finishes the quiz and takes the user to the final page.**/
    private void stopQuiz(){
        Intent resultIntent = new Intent();
        resultIntent.putExtra(Q_SCORE, score);
        setResult(RESULT_OK, resultIntent);
        Intent intent = new Intent(QuizActivity.this, FinalPage.class);
        startActivity(intent);
    }

    /**This handles if the user presses the back button on the phone.**/
    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            stopQuiz();
        } else {
            Toast.makeText(this, "Press back again to finish the quiz.", Toast.LENGTH_SHORT).show();
        }
        backPressedTime = System.currentTimeMillis();
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (timer != null){
            timer.cancel();
        }
    }
}
