package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This class handles the login functionality for the application.
 *
 */

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    private EditText uName, pWord;
    private Button b1, btnRegister;
    private UserDetailsDb db;
    public int timesCompleted;
    public static String userName;
    public static String passWord;
    Resources resources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new UserDetailsDb(this);
        uName = findViewById(R.id.txtUserName);
        pWord = findViewById(R.id.txtPass);
        btnRegister = findViewById(R.id.btnRegister);
        timesCompleted = timesCompleted +1;
        b1 = findViewById(R.id.btnLogin);
        resources = b1.getResources();


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Checks user details from database.
                passWord = pWord.getText().toString();
                userName = uName.getText().toString();

                Boolean checkDetails;
                checkDetails = db.checkDetails(userName, passWord);
                // If the details are correct, display a login message and take user to start quiz page.
                //If the details are incorrect display a wrong details message until the user is successful.
                if (userName.length() == 0 || passWord.length()== 0)
                {
                    Toast.makeText(getApplicationContext(), "There is a blank field please fill them all in.", Toast.LENGTH_LONG).show();

                }
               else if(checkDetails==true)
                {
                    Toast.makeText(getApplicationContext(), "successfully logged in.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Wrong details.", Toast.LENGTH_SHORT).show();
                }

            }
        });
        // Take user to register page.
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(Login.this, Register.class);
               startActivity(intent);
            }
        });

    }
}