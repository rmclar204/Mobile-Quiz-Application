package com.example.honsprojectfinal;


/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This java class is used for handling the final page functions,
 * this includes the plotting of graph points and saving the users score to
 * a csv file that will be used later for analysis.
 *
 */

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

//Import required variables from different classes.
import static com.example.honsprojectfinal.MainActivity.uName;
import static com.example.honsprojectfinal.MainActivity.categoryName;
import static com.example.honsprojectfinal.MainActivity.runOnce;
import static com.example.honsprojectfinal.MainActivity.startTime;
import static com.example.honsprojectfinal.QuizActivity.numWrong;
import static com.example.honsprojectfinal.QuizActivity.score;
import static com.example.honsprojectfinal.MainActivity.s;


public class FinalPage extends AppCompatActivity {
    private TextView txtFinal;
    public TextView txtPercent;
    private Button btnBack;
    private Button btnNext;
    private Button btnMoreData;
    public static double difference;
    public static String  sDifference;
    public String sScore;
    public String sAttempt;
    public static String[] array;
    public static GraphView graph;
    public  Double Xval;
    public Double Yval;
    private UserDetailsDb db;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);
    public static String dataFileName = "/data/user/0/com.example.honsprojectfinal/" + uName + "scoreData" + ".csv";
    public String catName;
    Resources resources;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page);
        txtPercent = findViewById(R.id.txtPercent);
        btnMoreData = findViewById(R.id.btnMoreData);
        btnNext = findViewById(R.id.btnTimePage);
        txtFinal = findViewById(R.id.txtFinal);
        resources = txtFinal.getResources();


        //This is done simply for encouragement for the users.
        if (score > 5) {
            txtFinal.setText("Your Score for this attempt was " + score + ", Well Done !");
        }
        else{
            txtFinal.setText("Your Score for this attempt was " + score + ", Keep Practising and your score will get better");
        }


        catName = categoryName;
        txtPercent.append("You had " + numWrong + " answers Wrong " + uName);
        btnBack = findViewById(R.id.btnHome);
        sScore = Double.toString(numWrong);
        sAttempt = Double.toString(s);
        db = new UserDetailsDb(this);
        db.getWritableDatabase();
        graph = findViewById(R.id.graphView);
        DataPoint[] dp1 = new DataPoint[1];
        //This is added to fix a bug where the first plotted point would take up the full graph.
        dp1[0] = new DataPoint(0,0);
        BarGraphSeries<DataPoint> series1 = new BarGraphSeries<>(dp1);
        graph.addSeries(series1);

        //Check if this is the first time for creating this page, this was implemented as an error occurred when creating the page.
        if (!runOnce)
        {
            //This is used to measure how long the user has taken to complete the quiz
            difference = System.currentTimeMillis() - startTime;
            difference = difference / 1000;
            sDifference = Double.toString(difference);
            runOnce = true;
            //Write data to csv file called scoreData .csv
            writeFile();
            txtPercent.setText("You had " + numWrong + " answers Wrong " + uName);
            // Read data in from file, and place it into graph.
            readFile();
            //Sets graph attributes to fit correctly
            setGraph();
        }
        else {
          // If this is not the first time displaying the page, only display the graph, do not write to file.
            txtPercent.setText("You had " + numWrong + " answers Wrong " + uName);
            readFile();
            setGraph();
        }
        //Take user to home page
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FinalPage.this, MainActivity.class);
                startActivity(intent);
            }
        });
        //Take user to time results page
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FinalPage.this, TimeResultsPage.class);
                startActivity(intent);
            }
        });
        //Take user to raw data page
        btnMoreData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(FinalPage.this, RawDataPage.class);
                startActivity(intent);
            }
        });
    }

    //Set graph dimensions to fit input
   public void setGraph(){
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setScrollable(true);
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(21);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(30);
        graph.getViewport().setScrollable(true);
    }


    //Read file from data
    public void readFile(){
        BufferedReader br = null;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(dataFileName));
            //Read until final line is read.
            while ((sCurrentLine = br.readLine()) != null) {
                //Split data into appropriate sections.
                array = sCurrentLine.split(",");
                //Set x and y values to the appropriate values.
                Xval = Double.parseDouble(array[1]);
                Yval = Double.parseDouble(array[2]);
                //Add the values to a datapoint.
                DataPoint[] dp = new DataPoint[array.length];
                for (int i = 0; i < array.length; i++) {
                    dp[i] = new DataPoint(Xval, Yval);
                }
                //Add data to graph.
                BarGraphSeries<DataPoint> series = new BarGraphSeries<>(dp);
                graph.addSeries(series);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


    //Write data to file
    public void writeFile(){
        try {
            FileWriter fw = new FileWriter(dataFileName, true);
            //Write category to file
            fw.write(catName);
            fw.write(",");
            //Write attempt number to file
            fw.write(sAttempt);
            fw.write(",");
            //Write score to file
            fw.write(sScore);
            fw.write(",");
            //Write time taken to file.
            fw.write(sDifference);
            fw.write("\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
