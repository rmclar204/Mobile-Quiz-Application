package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This handles all the functionality for the questions database.
 *
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import androidx.annotation.RequiresApi;
import com.example.honsprojectfinal.QuizContract.*;
import java.util.ArrayList;
import java.util.List;

public class QuizDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "myQuiz.db";
    private static final int DATABASE_VERSION = 3;
    private static QuizDbHelper instance;
    private static SQLiteDatabase db;


    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public static synchronized QuizDbHelper getInstance(Context context){
        if (instance == null){
            instance = new QuizDbHelper(context.getApplicationContext());
        }
        return instance;
    }

    //Create categories and questions tables.
    @Override
    public void onCreate(SQLiteDatabase db) {
        QuizDbHelper.db = db;
        final String SQL_CREATE_CATEGORIES_TABLE ="CREATE TABLE " +
                CategoriesTable.TABLE_NAME + "( " +
                CategoriesTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CategoriesTable.COLUMN_NAME + " TEXT " +
                ")";
        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANS_NUMBER + " INTEGER," +
                QuestionsTable.COLUMN_CAT_ID + " INTEGER, " +
                QuestionsTable.COLUMN_IMAGE_ID + " INTEGER, " +
                "FOREIGN KEY (" + QuestionsTable.COLUMN_CAT_ID + ") REFERENCES " +
                CategoriesTable.TABLE_NAME + "(" + CategoriesTable._ID + ")" + "ON DELETE CASCADE" +
                ")";
        db.execSQL(SQL_CREATE_CATEGORIES_TABLE);
        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillCategoriesTable();
        fillQuestionsTable();
    }


    //Used to add categories.
    private void addCategory(CategorySetter categorySetter) {
        ContentValues cv = new ContentValues();
        cv.put(CategoriesTable.COLUMN_NAME, categorySetter.getName());
        db.insert(CategoriesTable.TABLE_NAME, null, cv);

    }
    //This gets all the categories from the database.
    public List<CategorySetter> getAllCategories(){
        List<CategorySetter> categorySetterList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + CategoriesTable.TABLE_NAME, null);

        if (c.moveToFirst()){
            do{
                CategorySetter categorySetter = new CategorySetter();
                categorySetter.setId(c.getInt(c.getColumnIndex(CategoriesTable._ID)));
                categorySetter.setName(c.getString(c.getColumnIndex(CategoriesTable.COLUMN_NAME)));
                categorySetterList.add(categorySetter);

            }while (c.moveToNext());
        }
        c.close();
        return categorySetterList;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CategoriesTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);


    }
    //Adds all categories to table.
    private void fillCategoriesTable() {
        CategorySetter c1 = new CategorySetter("General Knowledge");
        addCategory(c1);
        CategorySetter c2 = new CategorySetter("Mathematics");
        addCategory(c2);
        CategorySetter c3 = new CategorySetter("Logic");
        addCategory(c3);
    }

    //Adds all questions to table.
    private void fillQuestionsTable(){
        QuestionBank bank = new QuestionBank();
        bank.addQuestions();
    }

    //Used to add more questions to the questions table.
    public static void addQuestion(Question question){
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANS_NUMBER, question.getAnsNumber());
        cv.put(QuestionsTable.COLUMN_CAT_ID, question.getCategoryID());
        cv.put(QuestionsTable.COLUMN_IMAGE_ID, question.getImageID());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    //Gets questions from databases to be used in quiz.
    public ArrayList<Question> getQuestions(int categoryID){
        ArrayList<Question> questions = new ArrayList<>();
        db = getReadableDatabase();
        String selection = QuestionsTable.COLUMN_CAT_ID + " = ? ";
        String[] selectionArgs = new String[]{String.valueOf(categoryID)};
        Cursor c = db.query(
                QuestionsTable.TABLE_NAME,
                null,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setId(c.getInt(c.getColumnIndex(QuestionsTable._ID)));
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnsNumber(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANS_NUMBER)));
                question.setCategoryID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_CAT_ID)));
                question.setImageID(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_IMAGE_ID)));
                questions.add(question);
            }while (c.moveToNext());

        }
        c.close();
        return questions;
    }
}
