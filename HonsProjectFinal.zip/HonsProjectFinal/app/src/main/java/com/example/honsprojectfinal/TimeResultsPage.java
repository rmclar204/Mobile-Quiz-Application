package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This page is similar to the final page however it displays the time taken to complete the
 * quiz over each attempt.
 *
 */
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.BarGraphSeries;
import com.jjoe64.graphview.series.DataPoint;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static com.example.honsprojectfinal.FinalPage.dataFileName;
import static com.example.honsprojectfinal.FinalPage.sDifference;
import static com.example.honsprojectfinal.QuizActivity.numWrong;
import static com.example.honsprojectfinal.QuizActivity.score;

public class TimeResultsPage extends AppCompatActivity {
    private TextView txtScore;
    private Button btnBack;
    private Button btnHome;
    private double percentage;
    public static String[] timeArray;
    public static GraphView graph;
    public Double Xval;
    public Double Yval;
    private AlphaAnimation buttonClick = new AlphaAnimation(1F, 0.8F);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_results_page);
        txtScore = findViewById(R.id.txtScore);
        btnHome = findViewById(R.id.btnResults);
        percentage = (numWrong / score) * 100;
        if (numWrong > 100) {
            numWrong = 100;
        }
        if (percentage > 100)
        {
            percentage = 100;
        }
         graph = findViewById(R.id.graphView);
        DataPoint[] dp1 = new DataPoint[1];
        dp1[0] = new DataPoint(0,0);
        BarGraphSeries<DataPoint> series1 = new BarGraphSeries<>(dp1);
        graph.addSeries(series1);
        btnBack = findViewById(R.id.btnHome);
        readFile();
        setGraph();
        txtScore.setText("The time taken to complete this quiz was  " + sDifference + "  seconds");
        //Takes user to the home page.
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(TimeResultsPage.this, MainActivity.class);
                startActivity(intent);
            }
        });
        //Takes user back to results page
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.startAnimation(buttonClick);
                Intent intent = new Intent(TimeResultsPage.this, FinalPage.class);
                startActivity(intent);
            }
        });
    }
    //Sets Graph dimensions to fit data
    public void setGraph(){

        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setYAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(21);
        graph.getViewport().setMinY(0);
        graph.getViewport().setMaxY(300);
        graph.getViewport().setScrollable(true);
    }
    //Reads data file but only displays timed data
    public void readFile(){
        BufferedReader br = null;
        try {
            String sCurrentLine;
            br = new BufferedReader(new FileReader(dataFileName));
            while ((sCurrentLine = br.readLine()) != null) {
                timeArray = sCurrentLine.split(",");
                Xval = Double.parseDouble(timeArray[1]);
                Yval = Double.parseDouble(timeArray[3]);
                DataPoint[] dp = new DataPoint[timeArray.length];
                for (int i = 0; i < timeArray.length; i++) {
                    dp[i] = new DataPoint(Xval, Yval);
                }
                BarGraphSeries<DataPoint> series = new BarGraphSeries<>(dp);
                graph.addSeries(series);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) br.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}

