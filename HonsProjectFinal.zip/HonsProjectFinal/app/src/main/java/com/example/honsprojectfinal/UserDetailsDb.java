package com.example.honsprojectfinal;
/**
 * Author: Ross McLaren
 * Student ID:S1622962
 *
 * This class is used to handle the user details database functionality.
 *
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class UserDetailsDb extends SQLiteOpenHelper {


    public UserDetailsDb(@Nullable Context context) {

        super(context, "Login.db", null, 1);
    }
    //Creates new database with users details.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table user(" +
                "userName text primary key," +
                " passWord text, " +
                "timesAccessed double)");
    }

    //Used to verify users details when logging in.
    public boolean checkDetails(String userName, String passWord) {
        SQLiteDatabase db = this.getReadableDatabase();
        passWord = encrypt(passWord);

        Cursor cursor = db.rawQuery("select * from user where userName =? and passWord =?", new String[]{userName, passWord});
        return cursor.getCount() > 0;
    }

    //Used to check if the username is available when registering.
    public boolean checkUserName(String userName) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from user where userName =?", new String[]{userName});
        return cursor.getCount() > 0;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists user");
    }

    //Adds new user to database when registering.
    public boolean insert(String userName, String passWord, Double TIMESACCESSED) {
        SQLiteDatabase db = this.getWritableDatabase();
        passWord = encrypt(passWord);
        ContentValues contentValues = new ContentValues();
        contentValues.put("userName", userName);
        contentValues.put("passWord", passWord);
        contentValues.put("timesAccessed", TIMESACCESSED);
        long ins = db.insert("user", null, contentValues);
        return ins != 1;
    }

    //Used to update number of times accessed to keep track of attempts.
    public void update(String userName, double TIMESACCESSED) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("userName", userName);
        cv.put("timesAccessed", TIMESACCESSED);
        String[] args = new String[]{userName};
        db.update("user", cv,"userName =?", args);

    }

    //Gets the users attempt number from the database.
    public double getTimesAccessed(String userName) {
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = null;
        double empName = 0;
        try {
            cursor = db.rawQuery("SELECT timesAccessed FROM user WHERE UserName=?", new String[]{userName + ""});
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                empName = cursor.getDouble(cursor.getColumnIndex("timesAccessed"));
            }
            return empName;
        } finally {
            cursor.close();
        }
    }

    //Used for storing passwords securely.
    public static final String encrypt(final String s) {
        String md5 = null;
        if(null == s) return null;
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes(), 0, s.length());
            md5 = new BigInteger(1, digest.digest()).toString(16);
        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return md5;
    }


}